# *Enhancement.py* #

```python
# # ________________________________________________
__class__ = 'CS499'
__creator__ = 'Ethan Mayberry'
__email__ = 'Ethan.Mayberry@snhu.edu'
__username__ = 'aacuser'
__password__ = 'PiperCat2025'
__version__ = '2.0'
__status__ = 'In-Process'
# # ________________________________________________
print('# ' + '=' * 78)
print('Class: ' + __class__)
print('Creator: ' + __creator__)
print('Email: ' + __email__)
print('Username: ' + __username__)
print('Password: ' + __password__)
print('Version: ' + __version__)
print('Status: ' + __status__)
print('# ' + '=' * 78)

from Authentication import userAuthenticate, userLogout, getUserCurrent
import base64
import re
import dash_bootstrap_components as dbc
from bson import ObjectId
import dash
from passlib.hash import pbkdf2_sha256
from waitress import serve
from dash import Dash, dcc, html, Input, Output, State, callback as cb, MATCH, no_update, ALL, dash_table as dt
from dash.exceptions import PreventUpdate
import dash_leaflet as dl
import pandas as pd
from pymongo import MongoClient
from AnimalShelter_CRUD import AnimalShelter


try:
    df = pd.read_csv('aac_shelter_outcomes.csv', index_col=0)
    idAnimalIndex = df.columns.get_loc('idAnimal')
    df = df.astype(str)
    df.insert(idAnimalIndex, 'count_down_column', df.index.astype(str))
    unnamed_column = df.pop(df.columns[0])
    df.insert(0, 'Unnamed_Column', unnamed_column)
except FileNotFoundError:
    df = pd.DataFrame()


loginMo = dbc.Modal(
    [
        dbc.ModalHeader("Login"),
        dbc.ModalBody(
            [
                dcc.Input(id='inputUsername', type='text', placeholder='Select a username'),
                dcc.Input(id='inputPassword', type='password', placeholder='Choose a password'),
                html.Div(id='loginMessage', style={'color': 'green'})
            ]
        ),
        dbc.ModalFooter(
            dbc.Button('Login', id='loginButton', n_clicks=0, color='primary'),
        ),
    ],
    id='login',
    is_open=False,
)


app = dash.Dash(__name__, external_stylesheets=[dbc.themes.BOOTSTRAP])


print(df.columns)
print(df.head())


client = MongoClient('mongodb://aacuser:PiperCat2025@localhost:27017/AAC?authSource=AAC')
db = client['AAC']
collection = db['animals']
collection_users = db['users']


df = pd.DataFrame(list(collection.find({}, projection={'_id': 0})))

if 'idChip' not in df.columns:
    df['idChip'] = ''

if 'idAnimal' not in df.columns:
    df['idAnimal'] = range(1, len(df) + 1)


columns_order = [
    {"name": "idAnimal", "id": "idAnimal", "deletable": False, "selectable": True},
    {"name": "idChip", "id": "idChip", "deletable": False, "selectable": True, "presentation": "dropdown"},
] + [
    {"name": i, "id": i, "deletable": False, "selectable": True} for i in df.columns
    if i not in ["idAnimal", "idChip"] and i != "1"
]


def create_regex(keywords):
    return re.compile(".*" + ".*|.*".join(keywords) + ".*", re.IGNORECASE)


def get_filteredData(shelter, breed_keywords, sex, min_age, max_age, latLocation=None, longLocation=None):
    query = {"$or": [{"breed": {"$regex": create_regex(breed_keywords)}}]}
    if sex is not None:
        query["sex_upon_outcome"] = sex
    query["age_upon_outcome_in_weeks"] = {"$gte": min_age, "$lte": max_age}

 
    if latLocation is not None and longLocation is not None:
        query["latLocation"] = latLocation
        query["longLocation"] = longLocation

    return pd.DataFrame.from_records(shelter.getRecordCriteria(query))


filter_criteria = {
    'All': {
        'breed_keywords': [],
        'sex': "Intact Male",
        'min_age': 1,
        'max_age': 2
    },
    'Water': {
        'breed_keywords': ['newf', 'chesa', 'lab'],
        'sex': "Intact Female",
        'min_age': 26.0,
        'max_age': 156.0
    },
    'Mountain': {
        'breed_keywords': ['german', 'mala', 'old english', 'husk', 'rott'],
        'sex': "Intact Male",
        'min_age': 26.0,
        'max_age': 156.0
    },
    'Disaster': {
        'breed_keywords': ['german', 'golden', 'blood', 'dober', 'rott'],
        'sex': "Intact Male",
        'min_age': 20.0,
        'max_age': 300.0
    }
}


app.config.suppress_callback_exceptions = True
username = "aacuser"
password = "PiperCat2025"
shelter = AnimalShelter(password, username)
df = pd.DataFrame.from_records(collection.find({}, projection={'_id': 0}))


with open('Grazioso_Salvare_Logo.png', 'rb') as f:
    encoded_image = base64.b64encode(f.read())


current_filter_type = 'All'


app.layout = html.Div([
    dcc.Location(id='url', refresh=False),
    html.A([
        html.Center(html.Img(src='data:image/png;base64,{}'.format(encoded_image.decode()),
                             height=250, width=251))], href='https://www.snhu.edu', target="_blank"),
    html.Center(html.B(html.H1('CS499 Database Enhancement'))),
    html.Hr(),
    dcc.RadioItems(
        id='filter-type',
        options=[
            {'label': 'All', 'value': 'All'},
            {'label': 'Mountain or Wilderness Rescue', 'value': 'Mountain'},
            {'label': 'Water Rescue', 'value': 'Water'},
            {'label': 'Disaster Rescue or Individual Tracking', 'value': 'Disaster'},
        ],
        value='All'
    ),
    html.Hr(),

    html.Button('Open Register', id='openRegisterButton', n_clicks=0),
    dbc.Modal(
        [
            dbc.ModalHeader("Register"),
            dbc.ModalBody(
                [
                    dcc.Input(id='registerUsername', type='text', placeholder='Enter your username'),
                    dcc.Input(id='registerPassword', type='password', placeholder='Enter your password'),
                    html.Div(id='registerMessage', style={'color': 'blue'})
                ]
            ),
            dbc.ModalFooter(
                dbc.Button('Register', id='registerButton', n_clicks=0, color='primary'),
            ),
        ],
        id='register',
        is_open=False,
    ),


    html.Div([
        html.H3('Add New Animal Information', style={'textAlign': 'center'}),
        dcc.Input(id='newName', type='text', placeholder='Animal Name'),
        dcc.Input(id='newBreed', type='text', placeholder='Breed'),
        dcc.Input(id='newAge', type='number', placeholder='Age in Weeks'),
        dcc.Input(id='newSex', type='text', placeholder='Sex'),
        dcc.Input(id='newChipID', type='text', placeholder='Chip ID'),
        html.Div(id='debug-output'),
        html.Button('Add Animal', id='addAnimalButton', n_clicks=0, disabled=True),
    ], style={'width': '100%', 'margin': 'auto', 'text-align': 'center'}),
    html.Hr(),


    dt.DataTable(
        id='datatable-id',
        columns=columns_order,
        data=df.to_dict('records'),
        editable=True,
        row_selectable="single",
        selected_rows=[],
        filter_action="native",
        sort_action="native",
        page_action="native",
        page_current=0,
        page_size=10,
    ),
    html.Button('Open Login', id='openLoginButton', style={'display': 'block'}),
    loginMo,
    html.Div(id='auth-status'),
    html.Br(),
    html.Hr(),


    html.Div(
        id='mapID',
        style={'width': '750px', 'height': '500px', 'margin': 'auto'},
    ),
])


@app.callback(
    
        Output('newName', 'value'),
        Output('newBreed', 'value'),
        Output('newAge', 'value'),
        Output('newSex', 'value'),
        Output('newChipID', 'value'),
        Output('addAnimalButton', 'disabled'),
    ],
    [
        Input('addAnimalButton', 'n_clicks'),
        Input('auth-status', 'children'),
    ],
    [
        State('newName', 'value'),
        State('newBreed', 'value'),
        State('newAge', 'value'),
        State('newSex', 'value'),
        State('newChipID', 'value'),
    ],
    prevent_initial_call=True
)
def handle_AddAnimal_button(n_clicks, auth_status, name, breed, age, sex, idChip):
    if auth_status is not None:
        return '', '', '', '', '', False
    else:
        return '', '', '', '', '', True



@app.callback(
    [
        Output('auth-status', 'children'),
        Output('login', 'is_open'),
        Output('loginMessage', 'children'),
        Output('url', 'pathname'),
    ],
    [
        Input('loginButton', 'n_clicks'),
        Input('openLoginButton', 'n_clicks'),
    ],
    [
        State('inputUsername', 'value'),
        State('inputPassword', 'value'),
        State('url', 'pathname'),
        State('login', 'is_open'),
    ],
    prevent_initial_call=True

def userLogin(loginButtonClicks, openLoginClicks, username, password, url_pathname, isLoginModalOpen):
    try:

        if loginuttonClicks:
            authenticated = userAuthenticate(username, password)

            if authenticated:
                return (
                    f"Authentication Status: Welcome, {username}!",
                    False,
                    None,
                    url_pathname,
                )
            else:
                return (
                    "Authentication Status: Invalid username or password.",
                    True,
                    "Invalid username or password.",
                    url_pathname,
                )


        elif openLoginClicks:
            return no_update, True, no_update, no_update
        else:
            return no_update, no_update, no_update, no_update

    except Exception as e:
        print(f"Login Callback Error: {str(e)}")
        return (
            f"Authentication Status: Error - {str(e)}",
            False,
            None,
            url_pathname,
        )


@app.callback(
    Output('mapID', "children"),
    [Input('datatable-id', "selected_rows")]
)
def mapUpdate(selected_rows):
    global df
    toolTip = "Austin Animal Center"
    if not selected_rows:
        return [dl.Map(style={'width': '750px', 'height': '500px'}, center=(30.75, -97.48), zoom=10,
                       children=[dl.TileLayer(id="base-layer-id")])]

    try:
        dff = pd.DataFrame(df.iloc[selected_rows])
        if 'latLocation' in dff.columns and 'longLocation' in dff.columns:
            coordLat = float(dff['latLocation'].to_string().split()[1])
            coordLong = float(dff['longLocation'].to_string().split()[1])
            markerArray = (coordLat, coordLong)
        else:
            markerArray = (30.75, -97.48)

        popUpHeading = "Animal Name"
        popUpParagraph = dff['name'].iloc[0] if 'name' in dff.columns else "Unknown"

    except Exception as e:
        print(f"Error in mapUpdate callback: {str(e)}")
        return dash.no_update

    print(f"Update Map callback - Marker Array: {markerArray}")
    print(f"Update Map callback - Data: {df.head()}")
    return [dl.Map(style={'width': '700px', 'height': '450px'}, center=markerArray,
                   zoom=10, children=[dl.TileLayer(id="base-layer-id"),
                                      dl.Marker(position=markerArray, children=[
                                          dl.Tooltip(toolTip),
                                          dl.Popup([
                                              html.H1(popUpHeading),
                                              html.P(popUpParagraph)
                                          ])
                                      ])
                                      ])
            ]


@app.callback(
    Output('datatable-id', 'data'),
    [
        Input('filter-type', 'value'),
        Input('addAnimalButton', 'n_clicks')
    ],
    [
        State('newName', 'value'),
        State('newBreed', 'value'),
        State('newAge', 'value'),
        State('newSex', 'value'),
        State('newChipID', 'value'),
        State('datatable-id', 'data')
    ],
    prevent_initial_call=True
)
def dataUpdate(selected_filter_type, n_clicks, name, breed, age, sex, idChip, existing_data):
    global df, current_filter_type

    try:
        print("Triggered by:", dash.callback_context.triggered_id)

        if 'filter-type' in dash.callback_context.triggered_id:
            print("Filter type change")
            current_filter_type = selected_filter_type
            criteria = filter_criteria.get(current_filter_type, filter_criteria['All'])
            df_filtered = get_filteredData(shelter, **criteria)


            df_filtered = df_filtered.fillna('')

            df = df_filtered.copy()


            for record in df.to_dict('records'):
                if '_id' in record:
                    record['_id'] = str(record['_id'])

            print("Updated data:", df.to_dict('records'))
            return df.to_dict('records')

        elif 'addAnimalButton' in dash.callback_context.triggered_id:
            print("Add animal button clicked")

            if n_clicks > 0:
                new_animal = {
                    'name': name,
                    'breed': breed,
                    'age_upon_outcome_in_weeks': age,
                    'sex_upon_outcome': sex,
                    'idChip': idChip
                }


                collection.insert_one(new_animal)


                df = pd.DataFrame(list(collection.find({}, projection={'_id': 0})))


                df.to_csv('aac_shelter_outcomes.csv', index=False)

            for record in df.to_dict('records'):
                if '_id' in record:
                    record['_id'] = str(record['_id'])

            print("Updated data:", df.to_dict('records'))
            return df.to_dict('records')

    except Exception as e:
        print(f"Error: {str(e)}")
        return dash.no_update


@app.callback(
    [
        Output('register', 'is_open'),
        Output('registerMessage', 'children'),
        Output('debug-output', 'children'),
    ],
    [
        Input('openRegisterButton', 'n_clicks'),
        Input('registerButton', 'n_clicks'),
    ],
    [
        State('registerUsername', 'value'),
        State('registerPassword', 'value'),
        State('register', 'is_open'),
    ],
    prevent_initial_call=True
)
def registerManage(open_clicks, registerButtonClicks, usernameRegister, passwordRegister, is_register_modal_open):
    try:
        print("Callback triggered.")
        print(f"open_clicks: {open_clicks}, registerButtonClicks: {registerButtonClicks}")
        print(f"usernameRegister: {usernameRegister}, passwordRegister: {passwordRegister}, is_register_modal_open: {is_register_modal_open}")


        if open_clicks and not registerButtonClicks:
            print("Open Register button clicked.")
            return not is_register_modal_open, None, None


        elif registerButtonClicks:
            print("Click registered.")
            existing_user = collection_users.find_one({'username': usernameRegister})
            if existing_user:
                print("Please type a new Username. Already in use.")
                return is_register_modal_open, "Username already exists. Choose a different one.", None


            hashed_password = pbkdf2_sha256.hash(passwordRegister)


            result = collection_users.insert_one({'username': usernameRegister, 'password': hashed_password})


            if result.inserted_id:
                print("Registration successful. You can now log in!")
                return False, "Registration successful. You can now log in!", None
            else:
                print("user registration error.")
                return is_register_modal_open, "user registration error.", None


        else:
            print("No click detected.")
            return is_register_modal_open, None, None

    except Exception as e:
        print(f"Error in registration callback: {str(e)}")
        return is_register_modal_open, f"Error during registration: {str(e)}", None


if __name__ == '__main__':
    serve(app.server, host='0.0.0.0', port=8050)