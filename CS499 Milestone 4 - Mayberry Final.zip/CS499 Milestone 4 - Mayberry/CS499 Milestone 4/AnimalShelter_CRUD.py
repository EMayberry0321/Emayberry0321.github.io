# *AnimalShelter_CRUD.py* #
# # ________________________________________________
__class__ = 'CS499'
__creator__ = 'Ethan Mayberry'
__email__ = 'Ethan.Mayberry@snhu.edu'
__username__ = 'aacuser'
__password__ = 'PiperCat2025'
__version__ = '2.0'
__status__ = 'In-Process'
__description__ = 'Utilizes Dаsh аррliсаtion to mаnаge рet ԁаtа from аnimаl shelters input by users.'
# # ________________________________________________
print('# ' + '=' * 78)
print('Class: ' + __class__)
print('Creator: ' + __creator__)
print('Email: ' + __email__)
print('Username: ' + __username__)
print('Password: ' + __password__)
print('Version: ' + __version__)
print('Status: ' + __status__)
print('Description: ' + __description__)
print('# ' + '=' * 78)
 

from pymongo import MongoClient 
from bson.objectid import ObjectId
import urllib.parse

class AnimalShelter(object): 
    """ CRUD operations for Animal collection in MongoDB """ 
     _instance = None
        
    def __new__(cls, _password, _username='aacuser'):
        if cls._instance is None:
            cls._instance = super(AnimalShelter, cls).__new__(cls)
            username = urllib.parse.quote_plus(_username)
            password = urllib.parse.quote_plus(_password)
            # Connection for MongoDB
            cls._instance.client = MongoClient(f'mongodb://{username}:{password}@localhost:27017/?authSource=AAC')
            cls._instance.dataBase = cls._instance.client['AAC']
        return cls._instance

    def __init__(self, _password, _username='aacuser'): 
                self.records_updated = 0
                self.records_matched = 0
                self.records_deleted = 0

            
    # Complete this create method to implement the C in CRUD. 
    def create(self, data):
        if data:
            _insert_valid = self.dataBase.animals.insert_one(data)
            return _insert_valid.acknowledged
        else:
            return False
        
    def animalAddition(self, name, breed, age, sex):
        new_animal = {'name': name, 'breed': breed, 'age_upon_outcome_in_weeks': age, 'sex_upon_outcome': sex}
        return self.createRecord(new_animal)

    # Create method to implement the R in CRUD.
    def getRecordsId(self, post_id):
        _data = self.dataBase.animals.find_one({'_id': ObjectId(post_id)})
        return _data


    def getRecordsCriteria(self, criteria):
        if criteria:
            _data = list(self.dataBase.animals.find(criteria, {'_id': 0}))
        else:
            _data = list(self.dataBase.animals.find({}, {'_id': 0}))
        return _data
    
    # Create method to implement the U in CRUD.
    def update(self, query, new_value):
        if not query:
            raise Exception("No valid search criteria is present.")
        elif not new_value:
            raise Exception("No valid update value is present.")
        else:
            _update_valid = self.dataBase.animals.update_many(query, {"$set": new_value})
            self.records_updated = _update_valid.modified_count
            self.records_matched = _update_valid.matched_count
            return _update_valid.modified_count > 0
            
    # Create method to implement the D in CRUD.
    def delete(self, query):
        if not query:
            raise Exception("No valid search criteria is present.")
        else:
             # Tracks number of deleted records
            _delete_valid = self.dataBase.animals.delete_many(query)
            self.records_deleted = _delete_valid.deleted_count
            return _delete_valid.deleted_count > 0