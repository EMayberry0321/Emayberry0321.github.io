
# *Authentication.py*
# # ________________________________________________
__class__ = 'CS499'
__creator__ = 'Ethan Mayberry'
__email__ = 'Ethan.Mayberry@snhu.edu'
__username__ = 'aacuser'
__password__ = 'PiperCat2025'
__version__ = '2.0'
__status__ = 'In-Process'
# # ________________________________________________
print('# ' + '=' * 78)
print('Class: ' + __class__)
print('Creator: ' + __creator__)
print('Email: ' + __email__)
print('Username: ' + __username__)
print('Password: ' + __password__)
print('Version: ' + __version__)
print('Status: ' + __status__)
print('# ' + '=' * 78)



from passlib.hash import pbkdf2_sha256
from pymongo import MongoClient


client = MongoClient('mongodb://aacuser:PiperCat2025@localhost:27017/AAC?authSource=AAC')
db = client['AAC'] 
collection_users = db['users'] 

def userAuthenticate(username, password):
 
    user = collection_users.find_one({'username': username})

    if user and pbkdf2_sha256.verify(password, user['password']):
        return True
    else:
        return False

def userLogout():
    global userCurrent
    userCurrent = None

userCurrent = None 

def userAuthenticate(username, password):
    global userCurrent

    user = collection_users.find_one({'username': username})

    if user and pbkdf2_sha256.verify(password, user['password']):
        userCurrent = username
        return True
    else:
        userCurrent = None
        return False

def getUserCurrent():
    return userCurrent