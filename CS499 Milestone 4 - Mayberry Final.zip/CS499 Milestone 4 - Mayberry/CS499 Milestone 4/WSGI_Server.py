# *WSGI_Server.py*
# # ________________________________________________
__class__ = 'CS499'
__creator__ = 'Ethan Mayberry'
__email__ = 'Ethan.Mayberry@snhu.edu'
__username__ = 'aacuser'
__password__ = 'PiperCat2025'
__version__ = '2.0'
__status__ = 'In-Process'
# # ________________________________________________
print('# ' + '=' * 78)
print('Class: ' + __class__)
print('Creator: ' + __creator__)
print('Email: ' + __email__)
print('Username: ' + __username__)
print('Password: ' + __password__)
print('Version: ' + __version__)
print('Status: ' + __status__)
print('# ' + '=' * 78)


from Application import app
from Authentication import userAuthenticate, userLogout, getUserCurrent


if __name__ == "__main__":
    app.run_server()
